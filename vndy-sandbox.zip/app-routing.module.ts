import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {VndySandboxComponent} from "./vndy-sandbox/vndy-sandbox.component";
import {DatasetsComponent} from "./datasets/datasets.component";

const routes: Routes = [
  {
    path: 'vndy',
    component: VndySandboxComponent
  },
  {
    path: 'datasets',
    component: DatasetsComponent
  },
  {
    path: '',
    component: VndySandboxComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
