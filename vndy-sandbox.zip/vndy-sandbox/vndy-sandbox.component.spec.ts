import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VndySandboxComponent } from './vndy-sandbox.component';

describe('VndySandboxComponent', () => {
  let component: VndySandboxComponent;
  let fixture: ComponentFixture<VndySandboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VndySandboxComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VndySandboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
