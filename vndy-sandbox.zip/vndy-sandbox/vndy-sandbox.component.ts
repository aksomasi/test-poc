import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vndy-sandbox',
  templateUrl: './vndy-sandbox.component.html',
  styleUrls: ['./vndy-sandbox.component.scss']
})
export class VndySandboxComponent implements OnInit {

  data = [{
    title: 'Datasources',
    desc: 'Some text inside the first cardSome text inside the first card'
  },
    {
      title: 'Datasources 2',
      desc: 'Some text inside the first cardSome text inside the first card'
    },
    {
      title: 'Datasources 3',
      desc: 'Some text inside the first cardSome text inside the first card'
    },
    {
      title: 'Datasources 4',
      desc: 'Some text inside the first cardSome text inside the first card'
    }]
  constructor() { }

  ngOnInit(): void {
  }

}
